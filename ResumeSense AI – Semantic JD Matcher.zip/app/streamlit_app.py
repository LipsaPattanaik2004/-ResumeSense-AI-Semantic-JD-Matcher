import streamlit as st
from pathlib import Path
from src.resume_matcher import suggest_keywords, load_text_from_file

st.set_page_config(page_title='Resume Keyword Enhancer (rtCamp)', layout='centered')
st.title('Resume Keyword Enhancer — Tailored for rtCamp')

st.write('Upload your resume (.txt) and a Job Description (.txt). The tool suggests phrases from your resume that best match the JD. Add only truthful skills/phrases.')

col1, col2 = st.columns(2)
with col1:
    resume_file = st.file_uploader('Upload resume (.txt)', type=['txt'])
with col2:
    jd_file = st.file_uploader('Upload job description (.txt)', type=['txt'])

top_k = st.slider('Suggestions to show', 3, 30, 12)

if resume_file and jd_file:
    resume_text = resume_file.getvalue().decode('utf-8', errors='ignore')
    jd_text = jd_file.getvalue().decode('utf-8', errors='ignore')
    with st.spinner('Computing...'):
        suggestions = suggest_keywords(resume_text, jd_text, top_k=top_k)
    if not suggestions:
        st.warning('No candidate phrases found.')
    else:
        st.success('Top suggestions (phrase — score):')
        for phrase, score in suggestions:
            st.write(f"**{phrase}** — {score:.3f}")
        st.markdown('---')
        st.write('Tip: Add the top 3–6 suggested phrases truthfully into your resume (Skills, Summary, Projects).')
else:
    st.info('Upload both files to get suggestions. Use the sample files in the data/ folder.')
    if st.button('Load sample files'):
        sample_dir = Path(__file__).parents[1] / 'data'
        resume_path = sample_dir / 'sample_resume.txt'
        jd_path = sample_dir / 'sample_jd.txt'
        resume_text = load_text_from_file(str(resume_path))
        jd_text = load_text_from_file(str(jd_path))
        suggestions = suggest_keywords(resume_text, jd_text, top_k=top_k)
        if suggestions:
            for phrase, score in suggestions:
                st.write(f"**{phrase}** — {score:.3f}")
