# resume-keyword-enhancer

**Purpose:** Assist applicants (like for rtCamp) by suggesting relevant resume keywords/phrases based on a Job Description (JD).  
This repo is tailored to the rtCamp Associate Python Engineer JD: demonstrates Python fundamentals, modular code, a small UI, and a clear README so reviewers can run the demo and evaluate code quality.

---

## Structure
- `src/` - production-ready Python modules
- `app/` - Streamlit demo app
- `notebooks/` - demonstration Jupyter notebook
- `data/` - sample resume and rtCamp JD
- `docs/` - original resume PDF (copied from user)
- `assets/` - screenshots (optional)
- `requirements.txt` - Python dependencies

---

## Quick start (for reviewers / rtCamp)
1. Clone repo
2. Create and activate virtual environment
   ```bash
   python -m venv .venv
   source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Run Streamlit demo:
   ```bash
   streamlit run app/streamlit_app.py
   ```
4. Upload your resume (txt) and JD (txt) in the UI, or use the provided sample files in `data/`.

---

## Notes for rtCamp reviewers
- This project uses `sentence-transformers` for semantic matching (small model `all-MiniLM-L6-v2`) to compare resume phrases with the JD.
- Code is modular: core logic in `src/resume_matcher.py`. The notebook demonstrates how to reproduce outputs and test locally.
- The `docs/` folder contains the original uploaded resume PDF for reference.

---

## How this matches the rtCamp JD
- **Python fundamentals**: core code is vanilla Python, functions are unit-testable.
- **Backend mindset**: modular design, separation of logic and UI, simple API-like function signatures.
- **Open-source readiness**: clear README, small demo, and instructions for contribution.
- **Frappe readiness**: demonstrates data -> process -> UI flow; easy to port the core logic into a Frappe app in Month 1.

---
