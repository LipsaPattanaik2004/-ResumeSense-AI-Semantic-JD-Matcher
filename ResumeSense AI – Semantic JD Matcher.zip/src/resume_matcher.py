"""src/resume_matcher.py

Core functions:
- load_text_from_file(path)
- extract_candidate_phrases(text)
- suggest_keywords(resume_text, jd_text, top_k=12)

Designed to be small, readable, and explainable for code reviews.
"""
from typing import List, Tuple
import re
import nltk
from nltk import sent_tokenize, word_tokenize, pos_tag
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Ensure necessary punkt tokenizer is present; users may download if running first time.
try:
    nltk.data.find('tokenizers/punkt')
except:
    nltk.download('punkt', quiet=True)

MODEL = None
def get_model(name: str='all-MiniLM-L6-v2'):
    global MODEL
    if MODEL is None:
        MODEL = SentenceTransformer(name)
    return MODEL

def load_text_from_file(path: str) -> str:
    """Load text from a small .txt file. (For PDFs use external tools; we keep demo simple.)"""
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def extract_candidate_phrases(text: str, max_phrases=80) -> List[str]:
    """Simple, explainable extractor:
    - Break into sentences
    - Use POS tags to collect contiguous nouns/adjectives/verbs as candidate phrases
    - Return deduplicated phrases preserving order
    """
    sents = sent_tokenize(text)
    phrases = []
    for s in sents:
        toks = word_tokenize(s)
        tags = pos_tag(toks)
        cur = []
        for tok, tag in tags:
            if tag.startswith('NN') or tag.startswith('JJ') or tag.startswith('VB'):
                cur.append(tok)
            else:
                if cur:
                    phrase = ' '.join(cur)
                    phrase = re.sub(r'[^\\w\\s\\-]', '', phrase).strip()
                    if len(phrase) > 2:
                        phrases.append(phrase)
                    cur = []
        if cur:
            phrase = ' '.join(cur)
            phrase = re.sub(r'[^\\w\\s\\-]', '', phrase).strip()
            if len(phrase) > 2:
                phrases.append(phrase)
    # dedupe preserving order
    seen = set()
    uniq = []
    for p in phrases:
        lp = p.lower()
        if lp not in seen:
            seen.add(lp)
            uniq.append(p)
        if len(uniq) >= max_phrases:
            break
    return uniq

def suggest_keywords(resume_text: str, jd_text: str, top_k=12) -> List[Tuple[str, float]]:
    """Return top_k phrases from resume_text most semantically similar to jd_text."""
    model = get_model()
    candidates = extract_candidate_phrases(resume_text)
    if not candidates:
        return []
    jd_emb = model.encode([jd_text])
    cand_embs = model.encode(candidates)
    sims = cosine_similarity(cand_embs, jd_emb).squeeze(-1)
    idx = np.argsort(-sims)[:top_k]
    return [(candidates[i], float(sims[i])) for i in idx]

# If run as script: quick CLI demo
if __name__ == '__main__':
    import sys
    if len(sys.argv) < 3:
        print('Usage: python src/resume_matcher.py resume.txt jd.txt')
        sys.exit(1)
    res = load_text_from_file(sys.argv[1])
    jd = load_text_from_file(sys.argv[2])
    for phrase, score in suggest_keywords(res, jd, top_k=15):
        print(f"{phrase} --> {score:.4f}")
